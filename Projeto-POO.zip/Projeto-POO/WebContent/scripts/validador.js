/**
 * validação de frmNovoVeiculo
 */

function validar(){
	let modelo = frmNovoVeiculo.modelo.value
	let marca = frmNovoVeiculo.marca.value
	
	if(modelo === ""){
		alert("Modelo obrigatorio");
		frmNovoVeiculo.modelo.focus()
		return false
	} else if(marca === ""){
		alert("Marca obrigatorio");
		frmNovoVeiculo.marca.focus()
		return false
	} else {
		document.forms["frmNovoVeiculo"].submit()
	}
	
}