package model;

public class Carro extends Veiculo{ 
	public String porta;
	public String cor;
	public String placa;
	public String chassi;
	   
   	// Chamada implicita para o construtor de Veiculo
   	public Carro() {
	   
   	}
   
	// Chamada explicita para o construtor de Veiculo
   	public Carro(String marca, String modelo, String porta, String cor, String placa, String chassi) { 
      super(marca, modelo); 
      this.porta = porta; 
      this.cor = cor;
      this.placa = placa;
      this.chassi = chassi;
   	} 
   
   	public String getPorta() {
	   return porta;
   	}

	public void setPorta(String porta) {
		this.porta = porta;
	}

	public String getCor() {
		return cor;
	}

	public void setCor(String cor) {
		this.cor = cor;
	}
	public String getPlaca() {
		return placa;
	}

	public void setPlaca(String placa) {
		this.placa = placa;
	}
	public String getChassi() {
		return chassi;
	}

	public void setChassi(String chassi) {
		this.chassi = chassi;
	}

}
