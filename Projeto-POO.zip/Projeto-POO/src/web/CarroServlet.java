package web;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.CarroDAO;
import model.Carro;


@WebServlet("/")
public class CarroServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private CarroDAO carroDAO;
	
	public void init() {
		carroDAO = new CarroDAO();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();
		HttpSession session = request.getSession();
		String email = session.getAttribute("email").toString();
		String password = session.getAttribute("password").toString();
		
		try {
			switch (action) {
			case "/new":
				showNewForm(request, response);
				break;
			case "/insert":
				insertCarro(request, response);
				break;
			case "/delete":
				deleteCarro(request, response);
				break;
			case "/edit":
				showEditForm(request, response);
				break;
			case "/update":
				updateCarro(request, response);
				break;
			default:
				listUser(request, response);
				break;
			}
		} catch (SQLException ex) {
			throw new ServletException(ex);
		}
	}

	private void listUser(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<Carro> listCarro = carroDAO.selectAllCarro();
		request.setAttribute("listCarro", listCarro);
		RequestDispatcher dispatcher = request.getRequestDispatcher("car-list.jsp");
		dispatcher.forward(request, response);
	}

	private void showNewForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("car-form.jsp");
		dispatcher.forward(request, response);
	}

	private void showEditForm(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		Carro existingCarro = carroDAO.selectCarro(id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("car-form.jsp");
		request.setAttribute("user", existingCarro);
		dispatcher.forward(request, response);

	}

	private void insertCarro(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		String modelo = request.getParameter("modelo");
		String marca = request.getParameter("marca");
		String porta = request.getParameter("porta");
		String cor = request.getParameter("cor");
		String placa = request.getParameter("placa");
		String chassi = request.getParameter("chassi");
		Carro newCarro = new Carro(modelo, marca, porta, cor,placa, chassi);
		carroDAO.insertCarro(newCarro);
		response.sendRedirect("list");
	}

	private void updateCarro(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		String modelo = request.getParameter("modelo");
		String marca = request.getParameter("marca");
		String porta = request.getParameter("porta");
		String cor = request.getParameter("cor");
		String placa = request.getParameter("placa");
		String chassi = request.getParameter("chassi");

		Carro automovel = new Carro(modelo, marca, porta, cor, placa, chassi);

		carroDAO.updateCarro(automovel);
		response.sendRedirect("list");
	}

	private void deleteCarro(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		carroDAO.deleteCarro(id);
		response.sendRedirect("list");

	}

}
