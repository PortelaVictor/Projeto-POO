package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Carro;


public class CarroDAO {
    private String jdbcURL = "jdbc:mysql://localhost:3306/dbagencia?useSSL=false";
    private String jdbcUsername = "root";
    private String jdbcPassword = "root";

    private static final String INSERT_VEICULO_SQL = "INSERT INTO veiculo" + "  (modelo,marca,porta,cor,placa,chassi) VALUES " +
        " (?, ?, ?, ?, ?, ?);";

    private static final String SELECT_VEICULO_BY_ID = "select id,modelo,marca,porta,cor,placa,chassi from veiculo where id =?";
    private static final String SELECT_ALL_VEICULOS = "select * from veiculo";
    private static final String DELETE_VEICULO_SQL = "delete from veiculo where id = ?;";
    private static final String UPDATE_VEICULO_SQL = "update veiculo set modelo = ?,marca = ?,porta = ?,cor = ?,placa = ?,chassi = ? where id = ?;";

    public CarroDAO() {}

    protected Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return connection;
    }

    public void insertCarro(Carro carro) throws SQLException {
        System.out.println(INSERT_VEICULO_SQL);
        // try-with-resource statement will auto close the connection.
        try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(INSERT_VEICULO_SQL)) {
            preparedStatement.setString(1, carro.getModelo());
            preparedStatement.setString(2, carro.getMarca());
            preparedStatement.setString(3, carro.getPorta());
            preparedStatement.setString(4, carro.getCor());
            preparedStatement.setString(5, carro.getPlaca());
            preparedStatement.setString(6, carro.getChassi());
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
    }

    public Carro selectCarro(int id) {
        Carro carro = null;
        // Step 1: Establishing a Connection
        try (Connection connection = getConnection();
            // Step 2:Create a statement using connection object
            PreparedStatement preparedStatement = connection.prepareStatement(SELECT_VEICULO_BY_ID);) {
            preparedStatement.setInt(1, id);
            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            ResultSet rs = preparedStatement.executeQuery();

            // Step 4: Process the ResultSet object.
            while (rs.next()) {
                String modelo = rs.getString("modelo");
                String marca = rs.getString("marca");
                String porta = rs.getString("porta");
                String cor = rs.getString("cor");
                String placa = rs.getString("placa");
                String chassi = rs.getString("chassi");
                carro = new Carro(modelo, marca, porta, cor, placa, chassi);
              
                
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return carro;
    }

    public List < Carro > selectAllCarro() {

        // using try-with-resources to avoid closing resources (boiler plate code)
        List < Carro > carro = new ArrayList < > ();
        // Step 1: Establishing a Connection
        try (Connection connection = getConnection();

            // Step 2:Create a statement using connection object
            PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_VEICULOS);) {
            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            ResultSet rs = preparedStatement.executeQuery();

            // Step 4: Process the ResultSet object.
            while (rs.next()) {
                int id = rs.getInt("id");
                String modelo = rs.getString("modelo");
                String marca = rs.getString("marca");
                String porta = rs.getString("porta");
                String cor = rs.getString("cor");
                String placa = rs.getString("placa");
                String chassi = rs.getString("chassi");
                carro.add(new Carro(modelo, marca, porta, cor, placa, chassi));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return carro;
    }

    public boolean deleteCarro(int id) throws SQLException {
        boolean rowDeleted;
        try (Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(DELETE_VEICULO_SQL);) {
            statement.setInt(1, id);
            rowDeleted = statement.executeUpdate() > 0;
        }
        return rowDeleted;
    }

    public boolean updateCarro(Carro carro) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(UPDATE_VEICULO_SQL);) {
            statement.setString(1, carro.getModelo());
            statement.setString(2, carro.getMarca());
            statement.setString(3, carro.getPorta());
            statement.setString(4, carro.getCor());
            statement.setString(5, carro.getPlaca());
            statement.setString(6, carro.getChassi());
            statement.setInt(4, carro.getId());

            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}